# Cara membuat APK WiFiShare

Build lokal di lingkungan ChatGPT tidak tersedia karena Android SDK tidak terpasang dan unduhan Gradle diblokir. Workflow GitHub Actions disertakan agar APK debug dapat dibangun di runner Ubuntu.

1. Ekstrak ZIP ini.
2. Buat repository baru di GitHub, lalu unggah isi folder `source` ke repository (pastikan `.github/workflows/build-apk.yml` ikut terunggah).
3. Buka tab **Actions** dan pilih **Build WiFiShare APK**.
4. Tekan **Run workflow** dan tunggu sampai selesai.
5. Buka hasil run yang berhasil, lalu unduh artifact **WiFiShare-debug-apk**. Ekstrak artifact untuk memperoleh file `.apk`.

Catatan: APK yang dibuat adalah debug APK untuk instalasi/uji coba, bukan release APK bertanda tangan untuk distribusi Play Store. Fitur ganti nama SSID Wi-Fi Direct tetap dibatasi Android; nama koneksi ditentukan sistem/perangkat.
