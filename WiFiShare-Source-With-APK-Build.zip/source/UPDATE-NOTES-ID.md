# Catatan pembaruan WiFiShare

- Nama aplikasi, label Quick Settings, dan teks layanan yang terlihat pengguna diubah menjadi WiFiShare.
- Ikon launcher diganti dengan simbol Wi-Fi minimalis warna putih/sian di atas latar gelap.
- Nama service discovery Wi-Fi Direct diubah ke `_wifishare`.
- Ditambahkan keterangan batasan SSID pada layar kredensial.

## Penting tentang nama Wi-Fi

Aplikasi ini membuat grup Wi-Fi Direct melalui `WifiP2pManager.createGroup()`. API publik Android tidak menyediakan parameter untuk menetapkan SSID atau passphrase khusus saat membuat grup tersebut. Android/OEM yang menentukan nama seperti `DIRECT-...`. Karena itu, perubahan branding menjadi WiFiShare **tidak mengubah SSID radio yang benar-benar dipancarkan**. Mengaku sebaliknya akan menyesatkan. Untuk SSID yang dapat dikustomisasi, diperlukan mode hotspot/tethering sistem yang dikonfigurasi lewat UI Android yang didukung perangkat; aplikasi biasa tidak dapat mengubah hotspot sistem secara bebas.

## Build

Buka folder `source` di Android Studio dan jalankan Gradle Sync lalu Build APK. Build dan uji perangkat belum dilakukan dalam lingkungan penyusunan ini.
