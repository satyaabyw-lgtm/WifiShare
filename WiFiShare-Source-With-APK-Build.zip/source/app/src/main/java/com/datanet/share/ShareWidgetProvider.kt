package com.datanet.share

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.datanet.share.sender.SenderService

class ShareWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { updateOne(context, manager, it) }
    }
    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_TOGGLE) {
            val service = Intent(context, SenderService::class.java).apply { action = SenderService.ACTION_TOGGLE }
            try { androidx.core.content.ContextCompat.startForegroundService(context, service) }
            catch (_: Exception) {
                val launch = context.packageManager.getLaunchIntentForPackage(context.packageName)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                if (launch != null) context.startActivity(launch)
            }
            updateAll(context)
        }
    }
    companion object {
        const val ACTION_TOGGLE = "com.datanet.share.widget.TOGGLE"
        fun updateAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, ShareWidgetProvider::class.java))
            ids.forEach { updateOne(context, manager, it) }
        }
        private fun updateOne(context: Context, manager: AppWidgetManager, id: Int) {
            val active = context.getSharedPreferences("wifishare_state", Context.MODE_PRIVATE).getString("sender_status", "stopped") == "active"
            val views = RemoteViews(context.packageName, R.layout.share_widget)
            views.setTextViewText(R.id.widget_status, if (active) "Status: SHARING ON" else "Status: OFF")
            views.setTextViewText(R.id.widget_toggle, if (active) "STOP SHARING" else "START SHARING")
            val click = Intent(context, ShareWidgetProvider::class.java).setAction(ACTION_TOGGLE)
            val pending = PendingIntent.getBroadcast(context, 4100 + id, click, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            views.setOnClickPendingIntent(R.id.widget_toggle, pending)
            manager.updateAppWidget(id, views)
        }
    }
}
