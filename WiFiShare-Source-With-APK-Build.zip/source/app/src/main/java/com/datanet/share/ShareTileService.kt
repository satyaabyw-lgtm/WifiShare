package com.datanet.share

import android.content.Intent
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.os.Build
import androidx.core.content.ContextCompat
import com.datanet.share.sender.SenderService

/** Quick Settings shortcut. One tap starts/stops the sender sharing service. */
class ShareTileService : TileService() {
    override fun onStartListening() {
        super.onStartListening()
        refreshTile()
    }
    override fun onClick() {
        super.onClick()
        val intent = Intent(this, SenderService::class.java).apply { action = SenderService.ACTION_TOGGLE }
        try { ContextCompat.startForegroundService(this, intent) } catch (_: Exception) {
            startActivityAndCollapse(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        qsTile?.state = Tile.STATE_UNAVAILABLE
        qsTile?.label = "WiFiShare"
        qsTile?.updateTile()
    }
    private fun refreshTile() {
        val status = getSharedPreferences("wifishare_state", MODE_PRIVATE).getString("sender_status", "stopped")
        qsTile?.state = if (status == "active" || status == "starting") Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        qsTile?.label = if (status == "active") "Sharing ON" else "WiFiShare"
        qsTile?.updateTile()
    }
}
